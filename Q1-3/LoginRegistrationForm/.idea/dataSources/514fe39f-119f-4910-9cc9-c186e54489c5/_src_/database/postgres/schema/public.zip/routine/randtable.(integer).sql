CREATE FUNCTION randtable (numvalue integer) RETURNS TABLE(number numeric)
	LANGUAGE plpgsql
AS $$
BEGIN
FOR x in 0..numValue LOOP
  number := TRUNC(random()*100);
  RETURN NEXT;
END LOOP;
END;
$$
