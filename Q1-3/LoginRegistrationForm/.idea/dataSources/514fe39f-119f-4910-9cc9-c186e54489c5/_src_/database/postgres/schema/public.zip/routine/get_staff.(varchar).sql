CREATE FUNCTION get_staff (city_pattern character varying) RETURNS TABLE(name text, age integer)
	LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY SELECT upper(COMPANY.NAME), COMPANY.AGE
  FROM COMPANY WHERE COMPANY.ADDRESS LIKE city_pattern;
END;
  
$$
