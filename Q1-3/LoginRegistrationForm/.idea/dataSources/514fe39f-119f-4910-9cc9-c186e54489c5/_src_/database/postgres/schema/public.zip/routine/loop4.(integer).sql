CREATE FUNCTION loop4 (x integer) RETURNS void
	LANGUAGE plpgsql
AS $$
BEGIN
  FOR counter IN 0..x BY 2 LOOP
    RAISE NOTICE 'even number: %', counter;
  END LOOP;
END;
$$
