CREATE FUNCTION curve (VARIADIC inputs numeric[]) RETURNS double precision
	LANGUAGE plpgsql
AS $$
DECLARE
  sum   FLOAT;
  count INTEGER;
  num   INTEGER;
BEGIN
  count := 0;
  sum := 0;
  FOR num IN SELECT unnest(inputs)
  LOOP
    IF (num >= 60)
    THEN
      count := count + 1;
      sum := sum + num;
    END IF;
  END LOOP;
  IF (85 - (sum / count) < 0)
  THEN
    RAISE NOTICE 'The average of the class is % and it is higher than 85 so there is no need for a curve', (sum / count);
    RETURN 0;
  ELSE
    RETURN (85 - (sum / count));
  END IF;
END;
$$
