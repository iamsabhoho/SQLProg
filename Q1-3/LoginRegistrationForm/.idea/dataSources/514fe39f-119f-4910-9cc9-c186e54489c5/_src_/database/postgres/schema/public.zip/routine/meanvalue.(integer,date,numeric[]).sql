CREATE FUNCTION meanvalue (id integer, date date, VARIADIC inputs numeric[]) RETURNS integer
	LANGUAGE plpgsql
AS $$
DECLARE
  sum INTEGER;
  cnt INTEGER;
  num INTEGER;
BEGIN
  cnt := 0;
  sum := 0;

  FOR num IN SELECT unnest(inputs)
    LOOP
    cnt := cnt + 1;
    sum:= sum + num;
  END LOOP;
  RAISE NOTICE 'The id is %, the date %, average is %', id, date, sum/cnt;
  RETURN sum/cnt;
END;
$$
