CREATE FUNCTION getletter (score integer) RETURNS text
	LANGUAGE plpgsql
AS $$
BEGIN
  IF 100 <= score <= 90 THEN
    RETURN 'A';
  ELSEIF 90 > score >= 80 THEN
    RETURN 'B';
  ELSEIF  80 > score >= 70 THEN
    RETURN 'C';
  ELSEIF  70 > score >= 60 THEN
    RETURN 'D';
  ELSE
    RETURN 'F';
  END IF;
END;
$$
