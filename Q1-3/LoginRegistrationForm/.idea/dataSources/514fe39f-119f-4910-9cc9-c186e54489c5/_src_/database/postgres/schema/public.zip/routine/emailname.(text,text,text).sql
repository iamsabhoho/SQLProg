CREATE FUNCTION emailname (firstname text, lastname text, domain text DEFAULT 'pas.org'::text) RETURNS text
	LANGUAGE plpgsql
AS $$
  BEGIN
    RETURN concat(substr(firstname, 1, 1), '.', lastname, '@', domain);
  END;
  
$$
