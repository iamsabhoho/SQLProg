CREATE FUNCTION loop2 (x integer) RETURNS void
	LANGUAGE plpgsql
AS $$
BEGIN
  FOR counter IN REVERSE x..1 LOOP
    RAISE NOTICE 'Counter value is: %', counter;
  END LOOP;
END;
$$
