CREATE FUNCTION loop1 (x integer) RETURNS void
	LANGUAGE plpgsql
AS $$
  BEGIN
    FOR cnt IN 1..x LOOP
      RAISE NOTICE 'Counter value is: %', cnt;
    END LOOP;
  END;
  
$$
