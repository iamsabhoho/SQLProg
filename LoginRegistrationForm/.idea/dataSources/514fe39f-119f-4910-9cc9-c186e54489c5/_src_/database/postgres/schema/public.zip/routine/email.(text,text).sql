CREATE FUNCTION email (firstname text, lastname text) RETURNS text
	LANGUAGE plpgsql
AS $$
  BEGIN
    RETURN concat(substr(firstname, 1), lastname, '@pas.org');
  END;
  
$$
