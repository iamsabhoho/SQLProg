CREATE FUNCTION combineword (a text, b text) RETURNS text
	LANGUAGE plpgsql
AS $$
  BEGIN
    RETURN concat(initcap(a) + initcap(b));
  END;
  
$$
