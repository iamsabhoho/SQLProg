CREATE FUNCTION combineword (a character varying, b character varying) RETURNS text
	LANGUAGE plpgsql
AS $$
  BEGIN
    RETURN concat(initcap(a) + initcap(b));
  END;
  
$$
