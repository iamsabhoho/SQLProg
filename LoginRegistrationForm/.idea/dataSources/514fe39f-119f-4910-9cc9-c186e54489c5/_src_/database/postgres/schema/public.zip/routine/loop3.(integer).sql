CREATE FUNCTION loop3 (x integer) RETURNS void
	LANGUAGE plpgsql
AS $$
BEGIN
  FOR counter IN 1..x BY 2 LOOP
    RAISE NOTICE 'odd number: %', counter;
  END LOOP;
END;
$$
